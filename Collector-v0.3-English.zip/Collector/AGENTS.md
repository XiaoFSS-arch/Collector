# Collector task scope

For installation, read START_HERE.md only and run its one setup command.
Do not read source files or other guides, run tests, install optional packages,
scan Roblox, validate offsets, or collect data unless the user requests that work.
Stop after setup reports ready; summarize in one short sentence.
On failure, use the reported error and inspect only the relevant file. Do not
repeat a failed command unchanged or launch a broad investigation.
For collection tasks, read only the relevant part of COLLECTION_GUIDE.md.
