import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]


def copy_bundle(parent):
    target=Path(parent)/'Collector'
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('.venv','__pycache__'))
    return target


def setup(root):
    return subprocess.run([sys.executable,'-B',str(root/'setup_collector.py')],capture_output=True,text=True,encoding='utf8')


class SetupTests(unittest.TestCase):
    def test_core_install_reuse_and_no_pip(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=copy_bundle(tmp);first=setup(root)
            self.assertEqual(first.returncode,0,first.stdout+first.stderr)
            report=json.loads(first.stdout);self.assertEqual(report['status'],'ready')
            self.assertFalse(report['environmentReused']);self.assertFalse(report['meshDependenciesRequested']);self.assertFalse(report['collectionStarted'])
            self.assertEqual(len(first.stdout.splitlines()),1);self.assertLess(len(first.stdout),1024)
            python=report['python']
            probe=subprocess.run([python,'-B','-c',"import importlib.util; assert importlib.util.find_spec('pip') is None; assert importlib.util.find_spec('numpy') is None"],capture_output=True)
            self.assertEqual(probe.returncode,0,probe.stderr)
            marker=root/'.venv/retain.txt';marker.write_text('retain',encoding='ascii')
            second=setup(root);self.assertEqual(second.returncode,0,second.stdout)
            self.assertTrue(json.loads(second.stdout)['environmentReused']);self.assertEqual(marker.read_text(),'retain')
            check=subprocess.run([python,'-B',str(root/'collector.py'),'cache-export','--help'],capture_output=True,text=True)
            self.assertEqual(check.returncode,0,check.stderr)

    def test_tampered_distribution_fails_before_environment_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=copy_bundle(tmp)
            with (root/'collector.py').open('a',encoding='ascii') as f:f.write('\n# changed\n')
            result=setup(root);self.assertNotEqual(result.returncode,0)
            report=json.loads(result.stdout);self.assertEqual(report['status'],'error')
            self.assertIn('collector.py',report['message']);self.assertFalse((root/'.venv').exists())

    def test_partial_environment_is_preserved_with_bounded_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=copy_bundle(tmp);env=root/'.venv';env.mkdir();marker=env/'retain.txt';marker.write_text('retain',encoding='ascii')
            result=setup(root);self.assertNotEqual(result.returncode,0)
            report=json.loads(result.stdout);self.assertEqual(report['status'],'error')
            self.assertIn('incomplete',report['message']);self.assertEqual(marker.read_text(),'retain')
            self.assertEqual(len(result.stdout.splitlines()),1);self.assertLess(len(result.stdout),1024)


if __name__=='__main__':unittest.main()
