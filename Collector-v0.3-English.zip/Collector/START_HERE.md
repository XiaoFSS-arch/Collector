# Quick installation

From this directory, run once with a working Python 3.10+ interpreter:

```powershell
python -B setup_collector.py
```

If Python is unavailable, report that requirement; do not search unrelated folders.
The default setup is offline, verifies shipped files, creates or reuses .venv,
skips pip and optional packages, and prints one JSON result. Stop at status ready.
It does not access Roblox. No code review, tests, layout work, or collection is
needed for installation. Consult detailed files only for an actual error or a
requested collection task. Mesh decoding is optional and can be added later with
`python -B setup_collector.py --with-mesh` (network required).
