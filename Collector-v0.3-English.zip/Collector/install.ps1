param([string]$Python = 'python', [switch]$WithMesh)
$ErrorActionPreference = 'Stop'
$setupArguments = @('-B', (Join-Path $PSScriptRoot 'setup_collector.py'))
if ($WithMesh) { $setupArguments += '--with-mesh' }
& $Python @setupArguments
if ($LASTEXITCODE -ne 0) { throw 'Setup failed. Use the reported error; do not start collection.' }
