"""Install the core tools offline; optional mesh dependencies are opt-in."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command):
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf8', errors='replace')
    if result.returncode:
        lines = (result.stderr or result.stdout).strip().splitlines()
        raise RuntimeError('Command failed: ' + ' | '.join(lines[-4:])[-1200:])
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--with-mesh', action='store_true', help='Install optional model dependencies; network required')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise RuntimeError('Use a working Python 3.10+ interpreter.')
    records = json.loads((ROOT/'MANIFEST.sha256.json').read_text(encoding='utf8'))
    import hashlib
    for row in records:
        path = (ROOT/row['path']).resolve()
        if not path.is_relative_to(ROOT.resolve()) or not path.is_file() or path.stat().st_size != row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise RuntimeError('Distribution integrity check failed: ' + row['path'])
    env = ROOT/'.venv'
    python = env/('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    reused = python.is_file()
    if not reused:
        if env.exists():
            raise RuntimeError('The .venv directory is incomplete. Choose a fresh extraction directory; no files were removed.')
        if importlib.util.find_spec('venv') is None:
            raise RuntimeError('This Python installation lacks venv support. Select a Python interpreter with venv.')
        run([sys.executable, '-m', 'venv', '--without-pip', str(env)])
    version = json.loads(run([str(python), '-B', '-c', 'import sys,json; print(json.dumps(list(sys.version_info[:2])))']))
    if tuple(version) < (3, 10):
        raise RuntimeError('The virtual environment needs Python 3.10+. Choose a fresh extraction directory.')
    if args.with_mesh:
        run([str(python), '-m', 'ensurepip', '--upgrade'])
        run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '--no-input', '-q', '-r', str(ROOT/'requirements-mesh.txt')])
        run([str(python), '-B', '-c', 'import numpy,DracoPy'])
    result = {'status':'ready', 'python':str(python), 'core':'ready', 'environmentReused':reused,
              'meshDependenciesRequested':args.with_mesh, 'collectionStarted':False}
    (env/'collector-setup.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, KeyError) as error:
        print(json.dumps({'status':'error','message':str(error),'collectionStarted':False}))
        raise SystemExit(1)
