"""Roblox collection utilities. Cache operations require only the Python standard library."""
import argparse
from contextlib import closing
import hashlib
import importlib.util
import json
import os
import platform
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def doctor(args):
    modules = ['numpy', 'DracoPy']
    report = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
              'windowsLiveReaderSupported': os.name == 'nt' and sys.maxsize > 2**32,
              'optionalDependencies': {m: importlib.util.find_spec(m) is not None for m in modules},
              'liveProcessAccessed': False, 'cacheOpened': False,
              'notes': ['Optional dependencies are needed only for mesh decoding.', 'Client layout and game schema require fresh validation.']}
    if args.output:
        write_json(args.output, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def verify(args):
    manifest = ROOT / 'MANIFEST.sha256.json'
    records = json.loads(manifest.read_text(encoding='utf8'))
    failures = []
    declared = set()
    for row in records:
        path = (ROOT / row['path']).resolve()
        if not path.is_relative_to(ROOT.resolve()):
            raise ValueError('Invalid manifest path')
        declared.add(row['path'])
        if not path.is_file() or path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
            failures.append(row['path'])
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and not {'.venv', '__pycache__'}.intersection(p.relative_to(ROOT).parts) and p.name != 'MANIFEST.sha256.json'}
    extras = sorted(actual - declared)
    print(json.dumps({'verified': len(records), 'failures': failures, 'extraFiles': extras, 'ok': not failures and not extras}, ensure_ascii=False))
    return 1 if failures or extras else 0


MAGIC = [(b'\x89PNG\r\n\x1a\n', 'png'), (b'\xabKTX 20\xbb\r\n\x1a\n', 'ktx2'),
         (b'<roblox!', 'rbxm'), (b'<roblox ', 'rbxmx'), (b'<roblox>', 'rbxmx'),
         (b'version 1.', 'mesh'), (b'version 2.', 'mesh'), (b'version 3.', 'mesh'),
         (b'version 4.', 'mesh'), (b'version 5.', 'mesh'), (b'version 6.', 'mesh'), (b'version 7.', 'mesh'),
         (b'OggS', 'ogg'), (b'fLaC', 'flac'), (b'ID3', 'mp3'), (b'\xff\xd8\xff', 'jpg'),
         (b'GIF87a', 'gif'), (b'GIF89a', 'gif')]


def payload_kind(raw):
    # Bare payload or RBXH response container. Unknown containers are skipped.
    if not raw.startswith(b'RBXH'):
        if raw.startswith(b'RIFF') and len(raw) >= 12:
            return (0, {'WEBP': 'webp', 'WAVE': 'wav'}.get(raw[8:12].decode('ascii', 'replace'))) if raw[8:12] in (b'WEBP', b'WAVE') else None
        return next(((0, ext) for marker, ext in MAGIC if raw.startswith(marker)), None)
    head = raw[:65536]
    found = [(at, ext) for marker, ext in MAGIC if (at := head.find(marker)) >= 0]
    at = head.find(b'RIFF')
    if at >= 0 and head[at+8:at+12] in (b'WEBP', b'WAVE'):
        found.append((at, 'webp' if head[at+8:at+12] == b'WEBP' else 'wav'))
    return min(found) if found else None


def cache_export(args):
    cache = args.cache_root.resolve()
    out = args.output.resolve()
    if out == cache or out.is_relative_to(cache) or cache.is_relative_to(out):
        raise ValueError('Output must be separate from the Roblox cache directory')
    if out.exists():
        raise ValueError('Output must be a new session directory')
    if args.limit < 1 or args.limit > 100000 or not 1 <= args.max_record_mib <= 1024:
        raise ValueError('Invalid record count/size bound')
    db = cache / 'rbx-storage.db'
    if not db.is_file():
        raise FileNotFoundError(db)
    clauses = []
    values = []
    if args.since_ms is not None:
        clauses.append('atime >= ?'); values.append(args.since_ms)
    if args.until_ms is not None:
        clauses.append('atime <= ?'); values.append(args.until_ms)
    if args.since_ms is not None and args.until_ms is not None and args.since_ms > args.until_ms:
        raise ValueError('since-ms must be <= until-ms')
    max_bytes = args.max_record_mib * 1024 * 1024
    counters = {'considered': 0, 'exported': 0, 'unknownFormat': 0, 'missing': 0, 'tooLarge': 0, 'errors': 0}
    with closing(sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)) as connection:
        columns = {r[1] for r in connection.execute('PRAGMA table_info(files)')}
        if not {'id', 'atime', 'content'} <= columns:
            raise ValueError('Unsupported cache schema; expected files(id, atime, content)')
        out.mkdir(parents=True)
        sql = 'SELECT id, atime, length(content) FROM files' + (' WHERE ' + ' AND '.join(clauses) if clauses else '') + ' ORDER BY atime DESC LIMIT ?'
        rows = connection.execute(sql, [*values, args.limit]).fetchall()
        with (out / 'index.jsonl').open('w', encoding='utf8') as index:
            for key, atime, inline_size in rows:
                counters['considered'] += 1
                key_text = bytes(key).hex() if isinstance(key, (bytes, bytearray, memoryview)) else str(key).lower()
                record = {'cacheKey': key_text, 'accessTimeMs': atime, 'assetId': None, 'ownership': 'candidate-unverified'}
                try:
                    if inline_size is not None:
                        size = inline_size
                        if size > max_bytes:
                            counters['tooLarge'] += 1; record['status'] = 'too-large'
                        else:
                            raw = connection.execute('SELECT content FROM files WHERE id = ?', (key,)).fetchone()[0]
                    else:
                        if not re.fullmatch(r'[0-9a-f]{16,128}', key_text):
                            raise ValueError('Unsupported external cache key')
                        source = cache / 'rbx-storage' / key_text[:2] / key_text
                        if not source.is_file():
                            counters['missing'] += 1; record['status'] = 'missing'
                        elif source.stat().st_size > max_bytes:
                            counters['tooLarge'] += 1; record['status'] = 'too-large'
                        else:
                            with source.open('rb') as f:
                                raw = f.read(max_bytes + 1)
                    if 'status' not in record and len(raw) > max_bytes:
                        counters['tooLarge'] += 1; record['status'] = 'too-large'
                    if 'status' not in record:
                        kind = payload_kind(raw)
                        if not kind:
                            counters['unknownFormat'] += 1; record['status'] = 'unknown-format'
                        else:
                            offset, extension = kind
                            payload = raw[offset:]
                            sha = hashlib.sha256(payload).hexdigest()
                            rel = f'payloads/{sha}.{extension}'
                            target = out / rel
                            target.parent.mkdir(exist_ok=True)
                            if not target.exists():
                                target.write_bytes(payload)
                            record.update(status='exported', format=extension, payload=rel, bytes=len(payload), sha256=sha, containerPrefixBytes=offset)
                            counters['exported'] += 1
                except (OSError, ValueError, TypeError, sqlite3.Error) as error:
                    counters['errors'] += 1
                    record.update(status='error', errorType=type(error).__name__)
                index.write(json.dumps(record, ensure_ascii=False) + '\n')
    summary = {'readOnlyCache': True, 'networkRequests': 0, 'filters': {'sinceMs': args.since_ms, 'untilMs': args.until_ms, 'limit': args.limit, 'maxRecordMiB': args.max_record_mib},
               'counts': counters, 'note': 'Format detection only. Cache time/key do not establish asset identity or game ownership; verify by current instance references and geometry/pixel checks.'}
    write_json(out / 'summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 2 if counters['errors'] else 0


def mesh_decode(args):
    import numpy as np
    from roblox_mesh_geometry import decode_geometry
    if args.output.exists():
        raise ValueError('Output must be a new directory')
    payload = args.input.read_bytes()
    result = decode_geometry(payload)
    args.output.mkdir(parents=True)
    arrays = {k: v for k, v in result.items() if isinstance(v, np.ndarray)}
    np.savez_compressed(args.output/'geometry.npz', **arrays)
    report = {'sourceSha256': hashlib.sha256(payload).hexdigest(), 'version': result['version'], 'lod': result['lod'], 'vertices': len(result['positions']), 'triangles': len(result['faces']), 'coordinateNormalization': False}
    write_json(args.output/'metadata.json', report)
    print(json.dumps(report))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    d = sub.add_parser('doctor', help='Report runtime and optional dependencies without reading the client/cache')
    d.add_argument('--output', type=Path); d.set_defaults(run=doctor)
    v = sub.add_parser('verify', help='Check the shipped file manifest; run before creating output inside this directory')
    v.set_defaults(run=verify)
    c = sub.add_parser('cache-export', help='Export a bounded set of local cached media/model payload candidates, read-only')
    c.add_argument('--cache-root', type=Path, default=Path.home()/'AppData/Local/Roblox')
    c.add_argument('--output', type=Path, required=True)
    c.add_argument('--since-ms', type=int); c.add_argument('--until-ms', type=int)
    c.add_argument('--limit', type=int, default=1000)
    c.add_argument('--max-record-mib', type=int, default=128)
    c.set_defaults(run=cache_export)
    m = sub.add_parser('mesh-decode', help='Decode FileMesh geometry to NPZ and metadata')
    m.add_argument('--input', type=Path, required=True); m.add_argument('--output', type=Path, required=True)
    m.set_defaults(run=mesh_decode)
    args = p.parse_args()
    return args.run(args) or 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, FileNotFoundError, sqlite3.Error) as error:
        print(f'{type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
