param(
  [string]$Python = 'python',
  [switch]$WithMesh
)
$ErrorActionPreference = 'Stop'
$toolRoot = $PSScriptRoot
$version = & $Python -c "import sys; assert sys.version_info >= (3, 10); print(sys.version.split()[0])"
if ($LASTEXITCODE -ne 0 -or -not $version) { throw 'A working Python 3.10+ executable is required.' }
$venvPython = Join-Path $toolRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
  & $Python -m venv (Join-Path $toolRoot '.venv')
  if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed.' }
}
if ($WithMesh) {
  & $venvPython -m pip install -r (Join-Path $toolRoot 'requirements-mesh.txt')
  if ($LASTEXITCODE -ne 0) { throw 'Optional mesh dependency installation failed.' }
}
& $venvPython -B (Join-Path $toolRoot 'collector.py') doctor
if ($LASTEXITCODE -ne 0) { throw 'Environment check failed.' }
Write-Output 'Collector ready. Use .venv/Scripts/python.exe to run collector.py or live.py.'
