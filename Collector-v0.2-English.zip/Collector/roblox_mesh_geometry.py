"""Decode static FileMesh geometry without normalizing source coordinates.

Supports binary v2-v5 and COREMESH v1/v2 in v6/v7. Returns primary LOD only.
Optional dependencies: numpy, DracoPy (v7).
"""
import struct
import numpy as np
from roblox_mesh_lods import primary_lod_info, effective_lod_offsets

def decode_geometry(data):
    version=data.split(b'\n',1)[0].decode('ascii')
    if version in ('version 6.00', 'version 7.00'):
        from roblox_mesh_lods import mesh_chunks
        revision,core=next((revision,chunk) for kind,revision,chunk in mesh_chunks(data) if kind==b'COREMESH')
        if revision==1:
            vertices=struct.unpack_from('<I',core)[0]
            if not 0 < vertices <= 5_000_000:raise ValueError('Invalid core vertex count')
            values=np.frombuffer(core,dtype='<f4',count=vertices*10,offset=4).reshape((-1,10))
            p=values[:,:3].copy();normals=values[:,3:6].copy();uv=values[:,6:8].copy()
            color=np.ndarray((vertices,4),dtype='u1',buffer=core,offset=40,strides=(40,1)).copy()
            offset=4+vertices*40;faces=struct.unpack_from('<I',core,offset)[0];offset+=4
            if faces>10_000_000 or len(core)!=offset+faces*12:raise ValueError('Invalid core face size')
            f=np.frombuffer(core,dtype='<u4',count=faces*3,offset=offset).reshape((-1,3)).copy()
        elif revision==2:
            from DracoPy import decode
            length=struct.unpack_from('<I',core)[0]
            if length!=len(core)-4:raise ValueError('Invalid Draco core size')
            mesh=decode(core[4:]);p=np.asarray(mesh.points,dtype='<f4');f=np.asarray(mesh.faces,dtype='<u4')
            normals=np.asarray(mesh.get_attribute_by_unique_id(1)['data'],dtype='<f4')
            uv=np.asarray(mesh.get_attribute_by_unique_id(2)['data'],dtype='<f4')
            # Draco unique IDs are not semantics: some encodings use ID 3 for the
            # packed tangent and ID 4 for COLOR. Select by attribute type instead.
            color=next((a for a in mesh.attributes if a['attribute_type']==2),None)
            color=np.asarray(color['data']) if color else None
        else:raise ValueError('Unsupported COREMESH revision '+str(revision))
        lod=primary_lod_info(data,len(f));f=f[lod['offsets'][0]:lod['offsets'][1]]
    else:
        start=data.index(b'\n')+1;header=struct.unpack_from('<H',data,start)[0];bones=0;lod_count=0;lod_type=None
        if version.startswith('version 2.'):
            _,stride,face_stride,vertices,faces=struct.unpack_from('<HBBII',data,start)
            if face_stride!=12:raise ValueError('Invalid face stride')
        elif version.startswith('version 3.'):
            _,stride,face_stride,_,lod_count,vertices,faces=struct.unpack_from('<HBBHHII',data,start)
        elif version.startswith(('version 4.','version 5.')):
            _,lod_type,vertices,faces,lod_count,bones=struct.unpack_from('<HHIIHH',data,start);stride=40
        else:raise ValueError('Unsupported mesh version '+version)
        if vertices>5_000_000 or faces>10_000_000 or stride not in (36,40):raise ValueError('Invalid vertex layout')
        offset=start+header
        values=np.ndarray((vertices,8),dtype='<f4',buffer=data,offset=offset,strides=(stride,4))
        p=values[:,:3].copy();normals=values[:,3:6].copy();uv=values[:,6:8].copy()
        color=np.ndarray((vertices,4),dtype='u1',buffer=data,offset=offset+36,strides=(stride,1)).copy() if stride==40 else None
        offset+=vertices*stride+bones*0
        # The envelope buffer exists once per vertex only when the mesh is skinned.
        if bones:offset+=vertices*8
        f=np.frombuffer(data,dtype='<u4',count=faces*3,offset=offset).reshape((-1,3)).copy();offset+=faces*12
        if lod_count>=2:
            source_offsets=list(struct.unpack_from('<'+'I'*lod_count,data,offset))
            lod_offsets=effective_lod_offsets(source_offsets,faces,lod_type)
            f=f[:lod_offsets[1]]
        else:source_offsets=lod_offsets=[0,faces]
        lod={'selected':0,'offsets':lod_offsets,'sourceOffsets':source_offsets,'lodType':lod_type,
             'levelCount':len(lod_offsets)-1,'sourceTriangles':faces,'renderedTriangles':len(f)}
    if not len(p) or not len(f) or not np.isfinite(p).all() or int(f.max())>=len(p):raise ValueError('Invalid geometry')
    return {'positions':p,'normals':normals,'uv':uv,'colors':color,'faces':f,'lod':lod,'version':version}
