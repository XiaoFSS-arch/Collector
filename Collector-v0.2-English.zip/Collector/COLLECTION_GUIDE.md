# Collection Guide

Start with directly observable information, establish an evidence chain from references to payloads, and then extend dynamic channels. Use a separate output directory, a finite time window, and an explicit scope for each session.

## Collection channels

| Information | Available entry point | Verification focus |
| --- | --- | --- |
| Image, audio, and model cache | `collector.py cache-export` | Output is a set of format candidates; decoding and resource identity checks are still required. |
| Static maps, buildings, and decorations | `live.py discover` and `snapshot` | Exact client version, root backlinks, explicit public paths, and validity after scene transitions. |
| Transforms, dimensions, colors, materials, and resource IDs | Verified `fields` in `snapshot` | Class-specific types, named property consumers, offsets, and control objects. |
| FileMesh geometry | `collector.py mesh-decode` | Vertices, faces, source dimensions, normals, UVs, LOD ranges, and input SHA256. |
| UI text, icons, and layout | Configured public GUI tree and corresponding fields | Anchors, dimensions, visibility, image references, and matching screenshots. Private player GUI is not read automatically. |
| Animation and skeletons | Cache candidates; additional format and runtime binding adapters required | AnimationId, rig, bones, keyframes, playback speed, and actual bindings. |
| Music and sound parameters | Public SoundService or an explicit public Sound tree and fields | SoundId, volume, speed, looping, and actual playback. A cache hit does not prove playback. |
| Particles, Trail, and Beam | Public static templates and fields; dynamic adapters required | Attachments, curves, lifetimes, actual clones versus templates. Complex types must not be read as arbitrary floats. |
| Combat and dynamic actors | Excluded from the static channel; dedicated source filters and samplers required | Local character and enemy attribution, live actors within the same wave, HUD transition boundaries, and displayed hits versus actual fields. |
| Configuration and client logic | No VM decoder included; version-specific adapters required | Types, structures, containers, instruction versions, constants, and actual consumers. Client observations are not authoritative server rules. |

## Layout adaptation

Confirm the exact executable version, then validate Name, Parent, Children, and the class descriptor structure. Public class-name strings can identify candidate instances; cross-check them through parent/child backlinks and multiple public services.

`discover` implements bounded string and reverse-reference scanning, but it still depends on a verified basic layout. It does not automatically discover every unknown layout.

Do not validate a property merely because its value looks plausible. Establish its type and storage from the named property binding or read path, then perform repeated reads and comparisons on known control objects. An original getter may provide a read-only analysis clue; do not execute it. Store evidence for each field in the layout and revalidate when the version changes or observations disagree.

The runtime implementation assumes 64-bit addresses, 32-byte MSVC strings, 16-byte child entries, and a particular class descriptor search shape. These are not permanently stable interfaces across all Roblox versions. A string or container shape change requires corresponding parser changes and sample validation.

First create a control sample linking the visible target, current root, actual node, field, snapshot, and SHA256. Begin continuous collection only after that chain is valid. Add bounded decoders for dynamic information and complex properties instead of enabling every class or traversing all account services.

## Resource identity

Use the following chain:

```text
Actual instance reference
  -> cache candidate
  -> payload content
  -> SHA256
  -> decoding, dimensions, geometry, or pixel comparison
```

Count instances, independent resource IDs, cache keys, and encoding/resolution variants separately. Access time only narrows the search; it does not assign a candidate to a game.

Original full-resolution images, reduced-resolution or BCn variants, and thumbnail evidence are different forms of evidence. When encoding hashes differ, compare pixels and actual usage. A thumbnail match is not proof of original-byte equality. Keep missing field reads, missing cache payloads, and unsupported formats as separate states.

Preserve decoded output separately from original bytes. Record the input SHA256, format version, and conversion parameters. When transferring to another engine, independently validate coordinate scale, directions and normals, CFrame/Pivot/Attachment behavior, UVs, color space, skinning, and animation interpolation. Do not assume a universal conversion factor.

## Stopping and evidence

Limit overhead by time, count, and size. Every command writes separate output and does not overwrite existing results by default. Runtime discovery has a time bound; snapshots have both time and node limits. Stop the current command when asked. An interrupted or incomplete snapshot must not be reported as complete.

Preserve failure diagnostics and the time of the last valid sample. A complete tree does not imply complete fields. A live process does not prove a valid root. Entering a stage does not prove completion. Health deltas or displayed values do not automatically establish base attack. Client constants and requests cannot prove the final server calculation.

Deliver original snapshots, payload indexes, per-file SHA256 hashes, and a coverage report. Distinguish verified data, candidates, inferences, missing information, and unsupported channels. After creating an archive, check its CRC, unique entry names, and extracted file hashes. Do not include authentication data, account saves, unrelated player information, or raw memory dumps.
