import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from live import load_layout, snapshot, field


class FakeReader:
    def __init__(self):
        self.layout = {'fields': {}}
        self.objects = {
            1: ('DataModel', 'DataModel', 0, [2, 3, 4]),
            2: ('Workspace', 'Workspace', 1, [5, 6]),
            3: ('ReplicatedStorage', 'ReplicatedStorage', 1, []),
            4: ('Players', 'Players', 1, []),
            5: ('Part', 'Ground', 2, []),
            6: ('Model', 'Actor', 2, [7]),
            7: ('Humanoid', 'Humanoid', 6, [])
        }
    def classname(self, a):return self.objects[a][0]
    def name(self, a):return self.objects[a][1]
    def parent(self, a):return self.objects[a][2]
    def children(self, a):return self.objects[a][3]


class LiveTests(unittest.TestCase):
    def test_layout_evidence_version_and_field_chain(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'layout.json'
            data = {'clientVersion':'version-test','verified':False,'verificationEvidence':None,'name':None,'parent':None,'children':None,'classDescriptor':None}
            path.write_text(json.dumps(data),encoding='utf8')
            with self.assertRaises(ValueError):load_layout(path,'version-test')
            data.update(verified=True,verificationEvidence='fixture-only',name='0x10',parent='0x20',children='0x30',classDescriptor='0x40')
            path.write_text(json.dumps(data),encoding='utf8')
            self.assertEqual(load_layout(path,'version-test')['name'],16)
            with self.assertRaises(ValueError):load_layout(path,'version-other')
        class Fields:
            def ptr(self,a):
                if a != 0x1010:raise AssertionError(a)
                return 0x2000
            def read(self,a,n):
                if a != 0x2020 or n != 4:raise AssertionError((a,n))
                return struct.pack('<f',12.5)
        spec={'chain':['0x10','0x20'],'type':'f32','verified':True,'evidence':'fixture-only'}
        self.assertEqual(field(Fields(),0x1000,spec),12.5)
        with self.assertRaises(ValueError):field(Fields(),0x1000,{**spec,'verified':False})

    def test_snapshot_backlinks_scope_and_truncation(self):
        reader=FakeReader()
        result=snapshot(reader,2,'Workspace',100,5)
        self.assertTrue(result['complete'])
        self.assertEqual([r['path'] for r in result['nodes']],['Workspace','Workspace/Ground'])
        self.assertFalse(snapshot(reader,2,'Workspace',1,5)['complete'])
        with self.assertRaises(ValueError):snapshot(reader,2,'Players',100,5)
        reader.objects[2]=('Workspace','Workspace',3,[5,6])
        with self.assertRaises(ValueError):snapshot(reader,2,'Workspace',100,5)


if __name__=='__main__':unittest.main(verbosity=2)
