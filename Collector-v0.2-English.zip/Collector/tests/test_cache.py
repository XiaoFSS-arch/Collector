import ast
from contextlib import closing
import base64
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

BUNDLE = Path(__file__).resolve().parents[1]
CLI = BUNDLE/'collector.py'
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=')
RESULTS = []


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(*args):
    return subprocess.run([sys.executable, '-B', str(CLI), *map(str,args)], capture_output=True, text=True, encoding='utf8')


def make_cache(root, records):
    root.mkdir()
    with closing(sqlite3.connect(root/'rbx-storage.db')) as db:
        db.execute('CREATE TABLE files (id BLOB PRIMARY KEY, atime INTEGER, content BLOB)')
        db.executemany('INSERT INTO files VALUES (?, ?, ?)', records)
        db.commit()


class PortableCollectorTests(unittest.TestCase):
    def test_inline_external_wrapper_dedup_and_readonly(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);cache=base/'cache';out=base/'out'
            make_cache(cache, [(bytes.fromhex('11'*16),100,b'RBXH\x01metadata\0'+PNG), (bytes.fromhex('22'*16),101,None), (bytes.fromhex('33'*16),102,b'unknown'), (bytes.fromhex('44'*16),103,None)])
            external=cache/'rbx-storage'/'22'/('22'*16);external.parent.mkdir(parents=True);external.write_bytes(PNG)
            before={p.relative_to(cache).as_posix():sha(p) for p in cache.rglob('*') if p.is_file()}
            result=run('cache-export','--cache-root',cache,'--output',out)
            self.assertEqual(result.returncode,0,result.stderr)
            report=json.loads(result.stdout);self.assertEqual(report['counts'],{'considered':4,'exported':2,'unknownFormat':1,'missing':1,'tooLarge':0,'errors':0})
            payloads=list((out/'payloads').glob('*'));self.assertEqual(len(payloads),1);self.assertEqual(payloads[0].read_bytes(),PNG)
            index=[json.loads(s) for s in (out/'index.jsonl').read_text(encoding='utf8').splitlines()]
            self.assertTrue(all(r['assetId'] is None and r['ownership']=='candidate-unverified' for r in index))
            self.assertTrue(any(r.get('containerPrefixBytes',0)>0 for r in index))
            after={p.relative_to(cache).as_posix():sha(p) for p in cache.rglob('*') if p.is_file()}
            self.assertEqual(before,after)
        RESULTS.append('inline/external/RBXH export + dedup + unknown/missing + unchanged input hashes')

    def test_filters_count_and_size_bounds(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);cache=base/'cache';out=base/'out'
            make_cache(cache,[(b'1'*16,100,PNG),(b'2'*16,200,PNG),(b'3'*16,300,b'ID3'+b'X'*(1024*1024))])
            result=run('cache-export','--cache-root',cache,'--output',out,'--since-ms',200,'--until-ms',300,'--limit',2,'--max-record-mib',1)
            self.assertEqual(result.returncode,0,result.stderr)
            counts=json.loads(result.stdout)['counts'];self.assertEqual(counts['considered'],2);self.assertEqual(counts['tooLarge'],1);self.assertEqual(counts['exported'],1)
            index=[json.loads(s) for s in (out/'index.jsonl').read_text(encoding='utf8').splitlines()]
            self.assertEqual({r['accessTimeMs'] for r in index},{200,300})
        RESULTS.append('inclusive time filters + explicit count + oversize record skip')

    def test_output_guards_schema_and_doctor(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);cache=base/'cache';make_cache(cache,[])
            for output in [cache, cache/'nested',base]:
                result=run('cache-export','--cache-root',cache,'--output',output)
                self.assertNotEqual(result.returncode,0)
            existing=base/'existing';existing.mkdir()
            self.assertNotEqual(run('cache-export','--cache-root',cache,'--output',existing).returncode,0)
            bad=base/'bad';bad.mkdir()
            with closing(sqlite3.connect(bad/'rbx-storage.db')) as db:
                db.execute('CREATE TABLE different (x)');db.commit()
            target=base/'unsupported';self.assertNotEqual(run('cache-export','--cache-root',bad,'--output',target).returncode,0);self.assertFalse(target.exists())
            doctor=run('doctor');self.assertEqual(doctor.returncode,0,doctor.stderr);data=json.loads(doctor.stdout);self.assertFalse(data['liveProcessAccessed']);self.assertFalse(data['cacheOpened'])
        RESULTS.append('cache/output separation + existing-session/schema rejection + no-client doctor')



if __name__ == '__main__':
    unittest.main(verbosity=2)
