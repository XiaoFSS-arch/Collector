"""Read FileMesh v6/v7 LOD face ranges without merging independent detail levels."""
import struct


def effective_lod_offsets(source_offsets, face_count, lod_type=None):
    # Production FileMesh assets with lodType=None can store [0, 0]:
    # the CORE contains one complete mesh, not an empty primary LOD.
    if lod_type == 0 and list(source_offsets) == [0, 0]:
        return [0, face_count]
    if len(source_offsets) < 2 or source_offsets[0] != 0 or source_offsets[-1] != face_count:
        raise ValueError('LOD offsets do not cover source triangles')
    if any(a >= b for a, b in zip(source_offsets, source_offsets[1:])):
        raise ValueError('LOD offsets are not strictly increasing')
    return list(source_offsets)


def mesh_chunks(payload):
    if not payload.startswith((b'version 6.00\n', b'version 7.00\n')):
        return
    cursor = 13
    while cursor < len(payload):
        if cursor + 16 > len(payload):
            raise ValueError('truncated FileMesh chunk header')
        kind = payload[cursor:cursor+8].rstrip(b'\0')
        version, size = struct.unpack_from('<II', payload, cursor+8)
        cursor += 16
        if cursor + size > len(payload):
            raise ValueError('truncated FileMesh chunk payload')
        yield kind, version, payload[cursor:cursor+size]
        cursor += size


def primary_lod_info(payload, face_count):
    offsets = [0, face_count]
    source_offsets = list(offsets)
    lod_type, high_quality = None, None
    for kind, version, data in mesh_chunks(payload):
        if kind != b'LODS':
            continue
        if version != 1 or len(data) < 7:
            raise ValueError('unsupported or truncated LODS chunk')
        lod_type, high_quality, count = struct.unpack_from('<HBI', data)
        if count < 2 or len(data) != 7 + 4*count:
            raise ValueError('invalid LOD offset count')
        source_offsets = list(struct.unpack_from('<'+'I'*count, data, 7))
        offsets = effective_lod_offsets(source_offsets, face_count, lod_type)
        break
    return {'selected': 0, 'offsets': offsets, 'levelCount': len(offsets)-1,
            'sourceTriangles': face_count, 'renderedTriangles': offsets[1]-offsets[0],
            'lodType': lod_type, 'highQualityLevels': high_quality,
            'sourceOffsets': source_offsets}
