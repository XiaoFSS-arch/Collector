# Collector

A standalone, local, read-only collection toolkit for Roblox. No game source code, web development environment, or account credentials are required to install it. Read this file first, then use `AI_PROMPT.txt` with your AI assistant.

## Features

- Environment checks and distribution file integrity verification.
- Local cache candidate export for image, model, and audio payloads, with SHA256 hashes, cache keys, and access timestamps.
- Windows x64 runtime root discovery and public static scene snapshots using an explicit client layout. No fixed game directory is embedded.
- Allowlisted sampling of independently verified fields, including resource references, numbers, vectors, and transforms, as defined in the layout.
- FileMesh geometry decoding for binary v2-v5 and supported COREMESH variants in v6/v7. Preserves source coordinates, UVs, normals, colors, and primary LOD, and exports NPZ arrays and metadata.

Cache export uses only the Python standard library and can be used independently right away. Runtime collection additionally requires Windows x64 and a verified layout for the exact client version. It rejects missing or unverified layouts instead of guessing offsets. No universal client offset table is included.

The archive contains no account data, cache database, source media assets, captured sessions, machine-specific paths, or personal information. It does not include a Python interpreter, third-party binaries, or an installed virtual environment.

## Installation

Use a working Python 3.10+ interpreter; x64 Python 3.12 is recommended. If the Windows `python` command is a Microsoft Store placeholder, substitute the path to a real interpreter.

Run these commands from the extracted directory:

```powershell
python -B collector.py verify
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Python python
.\.venv\Scripts\python.exe -B collector.py doctor
```

For optional model decoding support:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Python python -WithMesh
```

Alternatively, create an environment with `python -m venv .venv`, then use its interpreter to run the tools. Install optional model dependencies with that interpreter using `-m pip install -r requirements-mesh.txt`.

`-WithMesh` requires a network connection to install optional packages. The other installation steps do not access Roblox services. Cache export and environment checks do not require the optional packages.

`verify` checks the distribution files and ignores the `.venv` and Python cache directories created during installation. Keep collection output outside the toolkit directory.

## Cache collection

Open the target game and relevant interfaces normally, then run:

```powershell
.\.venv\Scripts\python.exe -B collector.py cache-export --output ..\captures\cache-001 --limit 1000
```

Optional arguments:

- `--cache-root`: the directory containing `rbx-storage.db` and `rbx-storage/`.
- `--since-ms` and `--until-ms`: an inclusive time window in UTC Unix milliseconds.
- `--max-record-mib`: maximum bytes read per record, in MiB; defaults to 128.

The output directory must be new. By default, the tool opens the current operating system user's Roblox cache read-only. It supports the `files(id,atime,content)` schema and both inline and external payloads. An incompatible schema produces an error.

Recognized candidates include PNG, KTX2, JPEG, GIF, WebP, RBXM/XML, FileMesh, OGG, FLAC, MP3 with an ID3 header, WAV, and supported RBXH containers. Unknown formats, oversized records, and missing entries are counted separately.

Output consists of `index.jsonl`, `summary.json`, and payload files deduplicated by content SHA256. Format recognition does not mean that the payload was decoded successfully or that it belongs to the target game. Cache keys and access timestamps are not AssetIds. Establish identity using actual instance resource references and geometry or pixel comparisons. The tool does not download resources or export response headers.

## Runtime collection

Read `COLLECTION_GUIDE.md`. Copy `layout.example.json` and fill in the exact version, offsets, and verification evidence only after independent validation. Do not set `verified` to true merely to bypass the checks.

```powershell
# Use Get-Process RobloxPlayerBeta to identify the target PID and executable version directory.
.\.venv\Scripts\python.exe -B live.py discover --pid 1234 --client-version version-REPLACE --layout verified-layout.json --output ..\captures\discovery-001.json --seconds 30
.\.venv\Scripts\python.exe -B live.py snapshot --pid 1234 --client-version version-REPLACE --layout verified-layout.json --discovery ..\captures\discovery-001.json --root-path Workspace/Map --output ..\captures\scene-001.json --seconds 30
```

The PID, version, and `Map` above are placeholders. Replace them with actual values. The tool verifies the process filename, version directory, executable SHA256, layout SHA256, and DataModel/Workspace/public service backlinks. Rediscover after scene transitions, instance invalidation, or process restarts.

`snapshot` accepts only explicit public service paths. It excludes player services, characters and other actors containing a Humanoid, script contents, and sensitive names. `complete` describes completeness only within the static tree and configured field scope; it does not mean that every kind of information has been collected.

Combat actors, animation, and dynamic effects require dedicated source filters and independently validated type decoders, followed by a control sample. These channels are not automatically implemented by this archive.

## Field definitions

Configure `fields` by class name and field name. Each field contains `chain`, `type`, `verified`, and `evidence`.

`chain` is an offset chain starting from the instance address. Every step except the last dereferences a pointer; the final offset identifies the value address. For example, `["0x100", "0x20"]` means `read_ptr(instance + 0x100) + 0x20`. These offsets demonstrate syntax only and must not be used as real values.

Supported types are `f32`, `f64`, `u32`, `i32`, `bool`, `vec3f`, `cframe12f`, `rgb8`, `string`, and `asset-string`. The string reader assumes a 32-byte MSVC string representation. `asset-string` exports only the numeric ID from a recognized asset reference.

Field layout, string representation, and class descriptor parsing are implementation assumptions that require client-specific validation. Adapt the code if the structure differs; changing numbers just to make checks pass is not validation. Each field needs its own evidence. Preserve unread values as null or errors rather than replacing them with zero.

## Model decoding and checks

```powershell
.\.venv\Scripts\python.exe -B collector.py mesh-decode --input ..\captures\cache-001\payloads\HASH.mesh --output ..\captures\mesh-001
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -p "test_*.py"
```

`geometry.npz` contains source geometry arrays. `metadata.json` records the input SHA256 and LOD information. Coordinates are not normalized. The decoder does not reconstruct full scenes or animations automatically, and future formats are not guaranteed to work. Unsupported formats should produce errors.

The three cache fixture tests and two runtime logic tests check the toolkit using offline samples. They do not establish successful live collection from any particular game. See `validation.json` for the checks performed for this distribution.

Process access is read-only: no injection, memory writes, or execution of original functions. Server-side information not replicated to the client, complete rules, and unloaded resources are not guaranteed to be available. Record read failures separately from evidence that information does not exist.
