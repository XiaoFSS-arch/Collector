# Collector v0.4 - Offline Windows x64

The archive contains the collector, CPython 3.14.10 embeddable runtime, NumPy
2.5.4, DracoPy 2.2.0, their native libraries, and license notices. Use this archive
on Windows 10/11 x64. No system Python or additional dependency downloads are
required after extracting it. `THIRD_PARTY.json` records official sources and
download hashes. Vendor licenses remain in runtime/LICENSE.txt and package
dist-info directories. This is a portable distribution, not a system installer.

## Setup

Run `Install.cmd`. It checks the shipped SHA256 manifest and imports local
dependencies, then emits one compact JSON result. It creates no virtual
environment, changes no system PATH, and runs no pip or network commands.
For installation through an AI assistant, provide `AI_PROMPT.txt`.

## Commands

```bat
Collector.cmd doctor
Collector.cmd cache-export --output ..\captures\cache-001 --limit 1000
Collector.cmd mesh-decode --input ..\captures\source.mesh --output ..\captures\mesh-001
Live.cmd --help
```

`Collector.cmd` and `Live.cmd` always use runtime/python.exe from this archive.
Use the bundled interpreter for custom commands as well. CPython's isolated
path configuration includes only bundled modules and collector sources.

Cache export reads local cache candidates and does not establish game ownership
from timestamps alone. Supported model decoding retains source geometry and UVs.
Read `COLLECTION_GUIDE.md` only when an actual collection task requires it.
Runtime discovery can find multiple DataModels, including application-shell or
stale scenes. Never assume the first root is the active game. If multiple roots
exist, identify the intended scene through independent current-scene evidence.
Snapshots exclude actors containing Humanoid and script contents. Missing fields
require independent property-layout validation. Configuration tables, scripts,
animations and combat are not automatically recovered by this static tool.

No game captures, credentials, personal machine configuration, or game-specific
layout are included. A separate live verification report, when provided, is
evidence for that session only. No complete game or server-rule recovery is
claimed. Updated layouts may be required after client changes.

The package fixes empty child-container handling and no longer stops discovery
after the first valid root. All root candidates must be considered before a
scene is chosen. No writes, injection, or original function calls are used.

Read validation.json for the exact offline checks and their limits. A clean
physical computer was not used for validation; a separate extraction with a
restricted environment and blocked Python socket operations was used instead.
