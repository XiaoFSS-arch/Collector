# Collector offline scope

Installation: read START_HERE.md only, run Install.cmd once, stop at ready.
Never download dependencies or use system Python; all tools are already bundled.
Do not run tests, inspect source, validate Roblox offsets, or collect data during
setup. On failure, report the specific error without broad searches or retries.
For actual collection, read only the relevant part of COLLECTION_GUIDE.md.
