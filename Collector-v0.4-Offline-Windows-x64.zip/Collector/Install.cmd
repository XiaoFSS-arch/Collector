@echo off
setlocal
if not exist "%~dp0runtime\python.exe" (
  echo {"status":"error","message":"Extract the complete archive before running Install.cmd."}
  exit /b 1
)
"%~dp0runtime\python.exe" -B "%~dp0setup_collector.py"
exit /b %errorlevel%
