@echo off
setlocal
"%~dp0runtime\python.exe" -B "%~dp0live.py" %*
exit /b %errorlevel%
