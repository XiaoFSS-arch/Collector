@echo off
setlocal
"%~dp0runtime\python.exe" -B "%~dp0collector.py" %*
exit /b %errorlevel%
