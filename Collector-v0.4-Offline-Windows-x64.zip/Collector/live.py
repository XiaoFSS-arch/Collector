"""Bounded read-only instance discovery and snapshots using an explicit client layout."""
import argparse
import ctypes
import ctypes.wintypes as w
import hashlib
import json
import math
import re
import struct
import time
from pathlib import Path


def offset(value):
    result = int(value, 0) if isinstance(value, str) else value
    if not isinstance(result, int) or isinstance(result, bool) or not 0 <= result <= 0x100000:
        raise ValueError('Invalid or missing layout offset')
    return result


def load_layout(path, version):
    data = json.loads(path.read_text(encoding='utf8'))
    if data.get('clientVersion') != version or data.get('verified') is not True or not data.get('verificationEvidence'):
        raise ValueError('Supply a verified layout for the exact client version, with verification evidence')
    for key in ('name', 'parent', 'children', 'classDescriptor'):
        data[key] = offset(data.get(key))
    return data


class Reader:
    def __init__(self, pid, layout):
        self.layout = layout
        self.k = ctypes.WinDLL('kernel32', use_last_error=True)
        self.k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        self.k.OpenProcess.restype = w.HANDLE
        self.k.ReadProcessMemory.argtypes = [w.HANDLE, w.LPCVOID, w.LPVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        self.k.ReadProcessMemory.restype = w.BOOL
        self.k.CloseHandle.argtypes = [w.HANDLE]
        self.handle = self.k.OpenProcess(0x410, False, pid)
        if not self.handle:
            raise OSError(ctypes.get_last_error(), 'Read-only process access failed')

    def close(self):
        if self.handle:
            self.k.CloseHandle(self.handle); self.handle = None

    def read(self, address, size):
        if not 0x10000 < address < 0x7fffffffffff or not 0 < size <= 4*1024*1024:
            return b''
        data = ctypes.create_string_buffer(size); count = ctypes.c_size_t()
        self.k.ReadProcessMemory(self.handle, ctypes.c_void_p(address), data, size, ctypes.byref(count))
        return data.raw[:count.value]

    def ptr(self, address):
        data = self.read(address, 8)
        return struct.unpack('<Q', data)[0] if len(data) == 8 else 0

    def string(self, address):
        data = self.read(address, 32)
        if len(data) != 32:
            return None
        length, capacity = struct.unpack_from('<QQ', data, 16)
        if not 0 < length <= 4096 or not length <= capacity < 8192:
            return None
        raw = data[:length] if capacity < 16 else self.read(struct.unpack_from('<Q', data)[0], length)
        if len(raw) != length:
            return None
        try:
            value = raw.decode('utf8')
            return value if all(c.isprintable() for c in value) else None
        except UnicodeDecodeError:
            return None

    def name(self, address):
        target = self.ptr(address+self.layout['name'])
        return next((value for delta in (8, 0, 16) if (value := self.string(target+delta))), None)

    def classname(self, address):
        descriptor = self.ptr(address+self.layout['classDescriptor'])
        for delta in (8, 16, 24, 0):
            target = self.ptr(descriptor+delta)
            for candidate in (descriptor+delta, target, target+8, target+16):
                value = self.string(candidate)
                if value and value.isascii() and value.isidentifier() and value[0].isupper():
                    return value
        return None

    def children(self, address):
        container = self.ptr(address+self.layout['children'])
        if not container:
            return []
        data = self.read(container, 16)
        if len(data) != 16:
            raise ValueError('Unreadable child container')
        begin, end = struct.unpack('<QQ', data)
        if end < begin or (end-begin) % 16 or end-begin > 16*100000:
            raise ValueError('Invalid child container')
        if end == begin:
            return []
        raw = self.read(begin, end-begin)
        if len(raw) != end-begin:
            raise ValueError('Incomplete child container')
        return [struct.unpack_from('<Q', raw, i)[0] for i in range(0, len(raw), 16)]

    def parent(self, address):
        return self.ptr(address+self.layout['parent'])

    def identity(self):
        self.k.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
        self.k.QueryFullProcessImageNameW.restype = w.BOOL
        text = ctypes.create_unicode_buffer(32768); size = w.DWORD(32768)
        if not self.k.QueryFullProcessImageNameW(self.handle, 0, text, ctypes.byref(size)):
            raise ValueError('Cannot verify executable identity')
        exe = Path(text.value)
        if exe.name.lower() != 'robloxplayerbeta.exe' or exe.parent.name != self.layout['clientVersion']:
            raise ValueError('Executable/version mismatch')
        return {'clientVersion': exe.parent.name, 'executableSha256': hashlib.sha256(exe.read_bytes()).hexdigest()}


def validate_root(reader, workspace):
    if reader.classname(workspace) != 'Workspace' or reader.name(workspace) != 'Workspace':
        raise ValueError('Workspace identity expired')
    dm = reader.parent(workspace)
    if reader.classname(dm) != 'DataModel' or workspace not in reader.children(dm):
        raise ValueError('DataModel backlink failed')
    services = {reader.classname(c) for c in reader.children(dm) if reader.parent(c) == dm}
    if not {'Workspace', 'ReplicatedStorage', 'Players'} <= services:
        raise ValueError('Public service backlinks failed')
    return dm


def discover(reader, seconds):
    class MBI(ctypes.Structure):
        _fields_ = [('BaseAddress', ctypes.c_void_p), ('AllocationBase', ctypes.c_void_p), ('AllocationProtect', w.DWORD), ('PartitionId', w.WORD), ('RegionSize', ctypes.c_size_t), ('State', w.DWORD), ('Protect', w.DWORD), ('Type', w.DWORD)]
    reader.k.VirtualQueryEx.argtypes = [w.HANDLE, w.LPCVOID, ctypes.POINTER(MBI), ctypes.c_size_t]
    reader.k.VirtualQueryEx.restype = ctypes.c_size_t
    deadline = time.monotonic()+seconds; regions = []; address = 0; strings = set(); roots = set()
    while address < 0x7fffffffffff and time.monotonic() < deadline:
        info = MBI()
        if not reader.k.VirtualQueryEx(reader.handle, ctypes.c_void_p(address), ctypes.byref(info), ctypes.sizeof(info)):
            break
        start, size = info.BaseAddress or address, info.RegionSize
        if not size:
            break
        address = start+size
        if info.State == 0x1000 and info.Type == 0x20000 and not info.Protect & 0x101 and info.Protect & 0xEE:
            regions.extend((start+i, min(size-i, 4*1024*1024)) for i in range(0, size, 4*1024*1024))
    string_deadline = time.monotonic()+max(0, deadline-time.monotonic())/3
    for start, size in regions:
        if time.monotonic() >= string_deadline:
            break
        raw = reader.read(start, size); at = raw.find(b'Workspace\0')
        while at >= 0:
            if reader.string(start+at) == 'Workspace':
                strings.add(start+at)
            at = raw.find(b'Workspace\0', at+1)
    patterns = [struct.pack('<Q', a+d) for a in strings for d in (0, -8, -16)]
    for start, size in regions:
        if time.monotonic() >= deadline:
            break
        raw = reader.read(start, size)
        for pattern in patterns:
            if time.monotonic() >= deadline:
                break
            at = raw.find(pattern)
            while at >= 0 and time.monotonic() < deadline:
                candidate = start+at-reader.layout['name']
                if candidate % 8 == 0:
                    try:
                        validate_root(reader, candidate); roots.add(candidate)
                    except ValueError:
                        pass
                at = raw.find(pattern, at+8)
    return sorted(roots)


PRIVATE = re.compile(r'password|token|cookie|account|userid|owner|authorization', re.I)


def field(reader, address, spec):
    if not spec.get('verified') or not spec.get('evidence'):
        raise ValueError('Field requires independent verification evidence')
    chain = spec['chain']
    if not 1 <= len(chain) <= 8:
        raise ValueError('Invalid field chain')
    for step in chain[:-1]:
        address = reader.ptr(address+offset(step))
    address += offset(chain[-1]); kind = spec['type']
    if kind in ('string', 'asset-string'):
        value = reader.string(address)
        if kind == 'asset-string' and value is not None:
            match = re.search(r'(?:rbxassetid://|[?&]id=)(\d+)', value)
            value = match.group(1) if match else None
        return value
    formats = {'f32':'f', 'f64':'d', 'u32':'I', 'i32':'i', 'bool':'?', 'vec3f':'3f', 'cframe12f':'12f', 'rgb8':'3B'}
    fmt = '<'+formats[kind]; raw = reader.read(address, struct.calcsize(fmt))
    if len(raw) != struct.calcsize(fmt):
        raise ValueError('Incomplete field')
    values = struct.unpack(fmt, raw)
    if any(isinstance(x, float) and not math.isfinite(x) for x in values):
        raise ValueError('Non-finite field')
    return values[0] if len(values) == 1 else list(values)


def snapshot(reader, workspace, root_path, max_nodes, seconds):
    dm = validate_root(reader, workspace)
    parts = root_path.split('/')
    if parts[0] not in ('Workspace', 'ReplicatedStorage', 'ReplicatedFirst', 'Lighting', 'SoundService'):
        raise ValueError('Choose an explicit public service path')
    current = dm
    for part in parts:
        matches = [c for c in reader.children(current) if reader.parent(c) == current and reader.name(c) == part]
        if len(matches) != 1:
            raise ValueError('Missing or ambiguous root path')
        current = matches[0]
    nodes = []; errors = []; stack = [(current, root_path, reader.parent(current))]; seen = set(); deadline = time.monotonic()+seconds
    while stack and len(seen) < max_nodes and time.monotonic() < deadline:
        address, path, parent = stack.pop()
        if address in seen:
            continue
        seen.add(address); kind = reader.classname(address); name = reader.name(address)
        if not kind or not name or reader.parent(address) != parent:
            errors.append({'path': path, 'error':'identity-changed'}); continue
        if kind in ('Player', 'Players', 'CoreGui', 'Script', 'LocalScript', 'ModuleScript') or PRIVATE.search(name):
            continue
        try:
            children = reader.children(address)
            # Character/actor captures need a dedicated source filter and are excluded here.
            if any(reader.classname(c) == 'Humanoid' for c in children):
                continue
            properties = {}
            for key, spec in reader.layout.get('fields', {}).get(kind, {}).items():
                if PRIVATE.search(key):
                    continue
                properties[key] = field(reader, address, spec)
            if reader.name(address) != name or reader.classname(address) != kind or reader.parent(address) != parent or reader.children(address) != children:
                raise ValueError('Instance changed during capture')
            nodes.append({'path':path, 'class':kind, 'properties':properties})
            for child in children:
                label = reader.name(child)
                if label:
                    stack.append((child, path+'/'+label, address))
                else:
                    errors.append({'path':path, 'error':'unreadable-child'})
        except (ValueError, KeyError) as error:
            errors.append({'path':path, 'error':type(error).__name__})
    validate_root(reader, workspace)
    return {'rootPath':root_path, 'nodes':nodes, 'errors':errors, 'complete':bool(nodes) and not errors and not stack,
            'scope':'Public static instance tree and configured fields only; actors/scripts excluded. Completeness is limited to this scope.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('discover', 'snapshot'))
    p.add_argument('--pid', type=int, required=True); p.add_argument('--client-version', required=True)
    p.add_argument('--layout', type=Path, required=True); p.add_argument('--output', type=Path, required=True)
    p.add_argument('--discovery', type=Path); p.add_argument('--root-path')
    p.add_argument('--workspace-address', type=lambda s: int(s, 0), help='Explicitly select one validated discovery candidate; does not prove it is the active game')
    p.add_argument('--seconds', type=float, default=30); p.add_argument('--max-nodes', type=int, default=20000)
    args = p.parse_args()
    if args.output.exists() or not 1 <= args.seconds <= 180 or not 1 <= args.max_nodes <= 100000:
        raise ValueError('Use a new output file and bounded seconds/nodes')
    layout = load_layout(args.layout, args.client_version)
    layout_sha = hashlib.sha256(args.layout.read_bytes()).hexdigest()
    reader = Reader(args.pid, layout)
    try:
        identity = reader.identity()
        if args.command == 'discover':
            roots = discover(reader, args.seconds)
            candidates = list(roots)
            if args.workspace_address is not None:
                if args.workspace_address not in roots:
                    raise ValueError('Selected Workspace is not a validated candidate')
                roots = [args.workspace_address]
            result = {'roots':roots, 'candidates':candidates, 'complete':len(roots) == 1,
                      'selection':'explicit' if args.workspace_address is not None else 'unique-candidate'}
        else:
            if not args.discovery or not args.root_path:
                raise ValueError('snapshot requires --discovery and --root-path')
            discovery = json.loads(args.discovery.read_text(encoding='utf8'))
            if discovery.get('pid') != args.pid or discovery.get('identity') != identity or discovery.get('layoutSha256') != layout_sha or len(discovery.get('roots', [])) != 1:
                raise ValueError('Discovery identity/layout mismatch; rediscover')
            result = snapshot(reader, discovery['roots'][0], args.root_path, args.max_nodes, args.seconds)
        if reader.identity() != identity:
            raise ValueError('Executable identity changed')
        result.update(pid=args.pid, identity=identity, layoutSha256=layout_sha, readOnly=True, capturedAt=time.time())
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open('x', encoding='utf8') as out:
            json.dump(result, out, ensure_ascii=False, indent=2, allow_nan=False)
        print(json.dumps({'complete':result['complete'], 'output':str(args.output)}, ensure_ascii=False))
        return 0 if result['complete'] else 2
    finally:
        reader.close()


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print(f'{type(error).__name__}: {error}')
        raise SystemExit(1)
