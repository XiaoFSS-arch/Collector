# Roblox 采集器

独立的本地只读采集工具。无需游戏源码、Web开发环境或账号凭据。先阅读本文件，再使用 `AI使用提示词.txt`。

## 功能

- 环境检查与文件完整性校验。
- 本地缓存候选导出：图片、模型、音频载荷；保存SHA256、来源缓存键与时间索引。
- Windows x64运行时根发现与公开静态场景快照：通过显式客户端布局读取，不附带固定游戏目录。
- 已核验字段白名单采样：资源引用、数值、向量、变换等，由布局定义决定。
- FileMesh几何解码：二进制v2～v5，以及v6/v7的受支持COREMESH变体，保留原坐标、UV、法线、颜色与首档LOD，输出NPZ和元数据。

缓存导出只需Python标准库，可立即独立使用。运行时采集另需Windows x64和对应客户端的已核验布局；未提供布局时明确拒绝运行，不猜偏移。此包未附带可供所有客户端通用的偏移表。

不含账号数据、缓存数据库、素材原件、采集记录、机器路径或个人资料。包内无Python解释器、第三方二进制或已安装虚拟环境。

## 安装

需要可正常执行的Python 3.10+，建议x64 3.12。Windows默认python命令若是商店占位程序，改用真实解释器路径。

在解压后的目录执行：

```powershell
python -B collector.py verify
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Python python
.\.venv\Scripts\python.exe -B collector.py doctor
```

需要模型解码时：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Python python -WithMesh
```

手动安装亦可：`python -m venv .venv`，再用虚拟环境解释器运行工具；模型功能可选执行 `python -m pip install -r requirements-mesh.txt`。`-WithMesh`需要联网安装可选依赖，其他安装步骤不访问Roblox服务。缓存和环境检查不依赖这两个可选包。

`verify`检查发行文件，忽略安装生成的`.venv`和Python缓存目录。采集输出放在工具目录之外，避免与发行文件混在一起。

## 缓存采集

正常打开目标游戏及所需界面后执行：

```powershell
.\.venv\Scripts\python.exe -B collector.py cache-export --output ..\captures\cache-001 --limit 1000
```

可选参数：`--cache-root`指定包含rbx-storage.db和rbx-storage目录的缓存根；`--since-ms`、`--until-ms`限定UTC Unix毫秒时间窗；`--max-record-mib`限制单条读取体积，默认128MiB。输出目录必须全新。

默认只读当前系统用户的Roblox缓存，支持`files(id,atime,content)`表和内联/外部载荷；不兼容结构会报错。支持识别PNG/KTX2/JPEG/GIF/WebP、RBXM/XML、FileMesh、OGG/FLAC/带ID3的MP3/WAV，以及受支持的RBXH封装。未知格式、过大或缺失条目分别计数。

输出`index.jsonl`、`summary.json`与按内容SHA256去重的payloads。此步识别的是载荷候选，不等于已完成解码或确认为目标游戏所用。缓存键和时间不能当AssetId；需用实际实例资源引用、几何或像素核对建立身份链。工具不会下载资源或导出响应头。

## 运行时采集

先看 `采集方法.md`。复制`layout.example.json`，按当前客户端独立核验后填写版本、偏移与证据。`verified`必须确实有验证依据，不能只为绕过检查改成true。

```powershell
# 先用 Get-Process RobloxPlayerBeta 核对唯一目标PID及可执行文件版本目录。
.\.venv\Scripts\python.exe -B live.py discover --pid 1234 --client-version version-REPLACE --layout verified-layout.json --output ..\captures\discovery-001.json --seconds 30
.\.venv\Scripts\python.exe -B live.py snapshot --pid 1234 --client-version version-REPLACE --layout verified-layout.json --discovery ..\captures\discovery-001.json --root-path Workspace/Map --output ..\captures\scene-001.json --seconds 30
```

以上PID、版本和Map都是占位符，必须换成实际值。工具校验进程文件名、版本目录、可执行文件SHA、布局SHA及DataModel/Workspace/服务回链；切场景、实例失效或进程重启后重新发现。

`snapshot`只接收显式公共服务路径，排除玩家服务、角色/含Humanoid的actor、脚本正文和敏感名称；`complete`仅表示当前静态树及配置字段范围的完整性，不表示所有资料齐全。需要战斗actor、动作/特效时，AI须先增加专用来源过滤与独立类型解码，再通过样本验证；这些通道不由本包自动完成。

## 字段定义

`fields`按类名和字段名配置，每字段包含`chain`、`type`、`verified`、`evidence`。`chain`是对象起始地址上的偏移链：除最后一步外都读取指针，最后一步是值地址。例如`["0x100", "0x20"]`表示`read_ptr(instance+0x100)+0x20`。这里的偏移仅演示写法，不应使用。

支持`f32/f64/u32/i32/bool/vec3f/cframe12f/rgb8/string/asset-string`；string按32字节MSVC字符串结构读取，asset-string只输出引用中的数字ID。字段布局、字符串表示和类描述符解析均是实现假设，须按客户端验证；结构不符时适配代码，不能仅修改数值让它通过。每字段需要单独证据，未读到保留null或错误，不补0。

## 模型解码与验证

```powershell
.\.venv\Scripts\python.exe -B collector.py mesh-decode --input ..\captures\cache-001\payloads\HASH.mesh --output ..\captures\mesh-001
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -p "test_*.py"
```

`geometry.npz`包含源几何数组，`metadata.json`记录来源SHA与LOD，不做坐标归一化。解码器不会自动复原完整场景/动画，也不保证支持未来格式；未知格式应报错。三项缓存离线用例与运行时纯逻辑样本用于检验工具，不代表某个游戏已实采通过。

进程读取使用只读权限，不注入、不写内存、不执行原函数。服务器未复制到客户端的资料、完整规则和未加载资源不保证可得。读取失败与资料不存在应分别记录。
